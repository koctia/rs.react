export interface ISearchBar {
  data?: string;
}
