export interface IHeaderName {
  name?: string;
}
