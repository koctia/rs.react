export interface IBreedsData {
  breed: number;
  name: string;
}
