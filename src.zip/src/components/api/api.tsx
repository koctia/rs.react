const fetchUrl = (link: string) =>
  fetch(link).then((response) => {
    return response.json();
  });

export { fetchUrl };
