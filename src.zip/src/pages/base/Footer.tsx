import React from 'react';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer__container">All Rights Reserved © RS.REACT, 2023</div>
    </footer>
  );
};

export { Footer };
